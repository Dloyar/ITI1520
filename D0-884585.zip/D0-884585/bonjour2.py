# Comments
# Student name: Rayold Rakotonomenjanahary 8884585
# This program prints a message

print("comment tu t'appel?)
x=input()
print("Bonjour!!!")
print("Rayold Rakotonomenjanahary")
print(x)
nom= input("Ecrit d'ou vien tu")
print(nom)
print("fini")
