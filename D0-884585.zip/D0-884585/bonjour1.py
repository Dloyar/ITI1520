# Comments
# Student name: Rayold Rakotonomenjanahary 8884585
# This program prints a message


x=input()
print("Bonjour!!!")
print("Rayold Rakotonomenjanahary")
print(x)
